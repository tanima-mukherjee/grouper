define([], () => {
  const models = {
    name: 'pignoseCalendar',
    version: '1.4.27',
    preference: {
      supports: {
        themes: ['light', 'dark', 'blue']
      }
    }
  };
  return models;
});
